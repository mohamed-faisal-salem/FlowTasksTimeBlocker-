
import React, { useState, useEffect, useMemo } from 'react';
import { TimeBlock, Task } from './types';
import { INITIAL_BLOCKS, ICONS } from './constants';
import { isActiveBlock, formatTime } from './utils';
import { useLocalStorage } from './hooks/useLocalStorage';
import BlockCard from './components/BlockCard';
import Tooltip from './components/Tooltip';

const App: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [blocks, setBlocks] = useLocalStorage<TimeBlock[]>('time-blocker-data', INITIAL_BLOCKS);
  const [theme, setTheme] = useLocalStorage<'dark' | 'light'>('time-blocker-theme', 'dark');

  // Update clock every minute
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Sync theme with document class for Tailwind dark: utility support
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const currentHour = currentTime.getHours();

  const handleAddTask = (blockId: string, text: string) => {
    const newTask: Task = {
      id: Math.random().toString(36).substr(2, 9),
      text,
      completed: false,
      createdAt: Date.now()
    };
    setBlocks(blocks.map(b => b.id === blockId ? { ...b, tasks: [...b.tasks, newTask] } : b));
  };

  const handleToggleTask = (blockId: string, taskId: string) => {
    setBlocks(blocks.map(b => b.id === blockId ? {
      ...b,
      tasks: b.tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t)
    } : b));
  };

  const handleDeleteTask = (blockId: string, taskId: string) => {
    setBlocks(blocks.map(b => b.id === blockId ? {
      ...b,
      tasks: b.tasks.filter(t => t.id !== taskId)
    } : b));
  };

  const handleUpdateVibe = (blockId: string, newVibe: string) => {
    setBlocks(blocks.map(b => b.id === blockId ? { ...b, vibeGoal: newVibe } : b));
  };

  const activeBlockId = useMemo(() => {
    return blocks.find(b => isActiveBlock(b, currentHour))?.id;
  }, [currentHour, blocks]);

  const toggleTheme = () => setTheme(theme === 'dark' ? 'light' : 'dark');

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-500 pb-20">
      
      {/* Navigation Bar */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <ICONS.Target />
            </div>
            <h1 className="text-xl font-extrabold tracking-tight">
              The Time <span className="text-indigo-600">Blocker</span>
            </h1>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex flex-col items-end mr-4">
              <p className="text-lg font-bold mono">{formatTime(currentTime)}</p>
              <p className="text-xs uppercase tracking-widest text-slate-500 font-bold">Synchronized</p>
            </div>
            
            <Tooltip text={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}>
              <button 
                onClick={toggleTheme}
                aria-label="Toggle Theme"
                className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:scale-105 active:scale-95 transition-all text-slate-700 dark:text-slate-300"
              >
                {theme === 'dark' ? <ICONS.Sun /> : <ICONS.Moon />}
              </button>
            </Tooltip>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 mt-8 lg:mt-12">
        
        {/* Welcome / Active Vibe Info */}
        <div className="mb-12">
          <div className="flex items-baseline gap-3 mb-2">
            <h2 className="text-3xl md:text-4xl font-black tracking-tight">
              Daily Spectrum
            </h2>
            <div className="h-2 flex-1 border-b border-slate-200 dark:border-slate-800"></div>
          </div>
          <p className="text-slate-500 dark:text-slate-400 font-medium max-w-2xl">
            A dynamic canvas for your daily rhythm. Organize tasks by your natural energy levels and intentions.
          </p>
        </div>

        {/* Grid Layout of Time Blocks */}
        <div className="grid grid-cols-1 gap-8">
          {blocks.slice().sort((a,b) => {
            // Sort logic: Handle the wrap-around starting from current hour or simply 0-23
            return a.startHour - b.startHour;
          }).map(block => (
            <BlockCard 
              key={block.id}
              block={block}
              isActive={block.id === activeBlockId}
              onAddTask={handleAddTask}
              onToggleTask={handleToggleTask}
              onDeleteTask={handleDeleteTask}
              onUpdateVibe={handleUpdateVibe}
            />
          ))}
        </div>

        {/* Footer Hints */}
        <footer className="mt-20 flex flex-col items-center gap-6 py-10 border-t border-slate-200 dark:border-slate-800">
          <div className="flex flex-wrap justify-center gap-6 md:gap-10">
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 text-[10px] md:text-xs font-semibold uppercase tracking-widest">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Local Persistence
            </div>
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 text-[10px] md:text-xs font-semibold uppercase tracking-widest">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              Dynamic Flow
            </div>
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 text-[10px] md:text-xs font-semibold uppercase tracking-widest">
              <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
              Zero Cloud footprint
            </div>
          </div>
        </footer>
      </main>

      {/* Floating Scroll-to-top (Mobile) */}
      <div className="fixed bottom-8 right-8 lg:hidden z-40">
        <button 
          onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
          className="w-14 h-14 rounded-full bg-indigo-600 text-white shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all"
        >
          <ICONS.Target />
        </button>
      </div>
    </div>
  );
};

export default App;
