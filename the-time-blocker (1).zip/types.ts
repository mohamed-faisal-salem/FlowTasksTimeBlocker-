
export type TimeBlockId = 'morning' | 'focus' | 'reset' | 'afternoon' | 'evening' | 'night' | 'sleep';

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
}

export interface TimeBlock {
  id: TimeBlockId;
  label: string;
  startHour: number; // 0-23
  endHour: number;   // 0-23
  vibeGoal: string;
  color: string;
  tasks: Task[];
}

export interface AppState {
  theme: 'dark' | 'light';
  blocks: TimeBlock[];
}
