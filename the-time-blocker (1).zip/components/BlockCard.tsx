
import React, { useState } from 'react';
import { TimeBlock, Task } from '../types';
import { ICONS } from '../constants';
import { getHourString } from '../utils';
import Tooltip from './Tooltip';

interface BlockCardProps {
  block: TimeBlock;
  isActive: boolean;
  onAddTask: (blockId: string, text: string) => void;
  onToggleTask: (blockId: string, taskId: string) => void;
  onDeleteTask: (blockId: string, taskId: string) => void;
  onUpdateVibe: (blockId: string, newVibe: string) => void;
}

const BlockCard: React.FC<BlockCardProps> = ({ 
  block, 
  isActive, 
  onAddTask, 
  onToggleTask, 
  onDeleteTask, 
  onUpdateVibe 
}) => {
  const [isEditingVibe, setIsEditingVibe] = useState(false);
  const [vibeInput, setVibeInput] = useState(block.vibeGoal);
  const [taskInput, setTaskInput] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (taskInput.trim()) {
      onAddTask(block.id, taskInput);
      setTaskInput('');
    }
  };

  const handleVibeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateVibe(block.id, vibeInput);
    setIsEditingVibe(false);
  };

  const colorClasses: Record<string, string> = {
    amber: 'border-amber-500/20 bg-amber-50/30 dark:bg-amber-950/10 text-amber-700 dark:text-amber-400',
    blue: 'border-blue-500/20 bg-blue-50/30 dark:bg-blue-950/10 text-blue-700 dark:text-blue-400',
    emerald: 'border-emerald-500/20 bg-emerald-50/30 dark:bg-emerald-950/10 text-emerald-700 dark:text-emerald-400',
    cyan: 'border-cyan-500/20 bg-cyan-50/30 dark:bg-cyan-950/10 text-cyan-700 dark:text-cyan-400',
    violet: 'border-violet-500/20 bg-violet-50/30 dark:bg-violet-950/10 text-violet-700 dark:text-violet-400',
    slate: 'border-slate-500/20 bg-slate-50/30 dark:bg-slate-950/10 text-slate-700 dark:text-slate-400',
    indigo: 'border-indigo-500/20 bg-indigo-50/30 dark:bg-indigo-950/10 text-indigo-700 dark:text-indigo-400',
  };

  const accentColors: Record<string, string> = {
    amber: 'bg-amber-500',
    blue: 'bg-blue-500',
    emerald: 'bg-emerald-500',
    cyan: 'bg-cyan-500',
    violet: 'bg-violet-500',
    slate: 'bg-slate-500',
    indigo: 'bg-indigo-500',
  };

  return (
    <div className={`group rounded-3xl border transition-all duration-500 overflow-hidden ${
      isActive 
        ? `ring-4 ring-offset-2 dark:ring-offset-slate-950 ring-${block.color}-500/20 scale-[1.01] shadow-xl` 
        : 'opacity-90 hover:opacity-100 shadow-sm border-slate-200 dark:border-slate-800'
    } ${colorClasses[block.color]}`}>
      
      {/* Header */}
      <div className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-inherit">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-2xl ${accentColors[block.color]} text-white shadow-lg`}>
            {isActive ? <ICONS.Target /> : <ICONS.Clock />}
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              {block.label}
              {isActive && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-current bg-opacity-10 uppercase tracking-tighter">
                  <span className="w-1.5 h-1.5 rounded-full bg-current mr-1.5 animate-pulse"></span>
                  Focusing
                </span>
              )}
            </h3>
            <p className="text-sm font-medium opacity-60 mono">
              {getHourString(block.startHour)} — {getHourString(block.endHour)}
            </p>
          </div>
        </div>

        <div className="flex-1 max-w-md">
          {isEditingVibe ? (
            <form onSubmit={handleVibeSubmit} className="flex gap-2">
              <input 
                autoFocus
                className="w-full bg-white dark:bg-slate-800 border-2 border-inherit rounded-xl px-4 py-2 text-sm font-medium focus:outline-none focus:ring-2 ring-current ring-opacity-50 text-slate-900 dark:text-white"
                value={vibeInput}
                onChange={(e) => setVibeInput(e.target.value)}
                onBlur={handleVibeSubmit}
              />
            </form>
          ) : (
            <div 
              onClick={() => setIsEditingVibe(true)}
              className="cursor-pointer group/vibe flex items-center gap-2 px-4 py-2 rounded-xl bg-white/50 dark:bg-black/20 hover:bg-white/80 dark:hover:bg-black/40 transition-all border border-slate-200/50 dark:border-transparent"
            >
              <div className="flex-1">
                <span className="text-[10px] uppercase tracking-wider font-bold opacity-40 block">Energy Intent</span>
                <span className="text-sm font-semibold italic text-slate-800 dark:text-slate-200">"{block.vibeGoal}"</span>
              </div>
              <div className="opacity-0 group-hover/vibe:opacity-100 transition-opacity">
                <ICONS.Edit />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Task List */}
      <div className="p-6 bg-white/40 dark:bg-slate-900/40 min-h-[160px]">
        <div className="space-y-2">
          {block.tasks.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 opacity-30 italic text-sm">
              <p>Energy flow is clear.</p>
              <p>Add a task to anchor this vibe.</p>
            </div>
          ) : (
            block.tasks.sort((a,b) => b.createdAt - a.createdAt).map(task => (
              <div key={task.id} className="group/task flex items-center gap-3 bg-white/80 dark:bg-slate-800/60 p-3 rounded-2xl hover:bg-white dark:hover:bg-slate-800 transition-all border border-slate-100 dark:border-transparent hover:border-inherit shadow-sm">
                <button 
                  onClick={() => onToggleTask(block.id, task.id)}
                  className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
                    task.completed 
                      ? `${accentColors[block.color]} text-white` 
                      : 'border-2 border-slate-300 dark:border-slate-600 hover:border-inherit'
                  }`}
                >
                  {task.completed && <ICONS.Check />}
                </button>
                <span className={`flex-1 text-sm font-medium ${task.completed ? 'line-through opacity-30 text-slate-500' : 'text-slate-800 dark:text-slate-200'}`}>
                  {task.text}
                </span>
                <button 
                  onClick={() => onDeleteTask(block.id, task.id)}
                  className="p-2 opacity-0 group-hover/task:opacity-100 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all"
                >
                  <ICONS.Trash />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Add Task Form */}
        <form onSubmit={handleAddSubmit} className="mt-6 flex gap-2">
          <input 
            type="text"
            placeholder="Anchor a task to this vibe..."
            className="flex-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:border-inherit rounded-2xl px-5 py-3 text-sm focus:outline-none shadow-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600"
            value={taskInput}
            onChange={(e) => setTaskInput(e.target.value)}
          />
          <Tooltip text="Add Task">
            <button 
              type="submit"
              className={`p-3 rounded-2xl ${accentColors[block.color]} text-white shadow-lg hover:brightness-110 active:scale-95 transition-all`}
            >
              <ICONS.Plus />
            </button>
          </Tooltip>
        </form>
      </div>
    </div>
  );
};

export default BlockCard;
