
import { TimeBlock } from './types';

export const INITIAL_BLOCKS: TimeBlock[] = [
  {
    id: 'sleep',
    label: 'Deep Sleep',
    startHour: 23,
    endHour: 5,
    vibeGoal: 'Total Recharge',
    color: 'indigo',
    tasks: []
  },
  {
    id: 'morning',
    label: 'Morning Rise',
    startHour: 5,
    endHour: 9,
    vibeGoal: 'Intentional Start',
    color: 'amber',
    tasks: []
  },
  {
    id: 'focus',
    label: 'Peak Focus',
    startHour: 9,
    endHour: 12,
    vibeGoal: 'Deep Work Flow',
    color: 'blue',
    tasks: []
  },
  {
    id: 'reset',
    label: 'Midday Reset',
    startHour: 12,
    endHour: 14,
    vibeGoal: 'Physical & Mental Break',
    color: 'emerald',
    tasks: []
  },
  {
    id: 'afternoon',
    label: 'Steady Flow',
    startHour: 14,
    endHour: 17,
    vibeGoal: 'Execution & Collaboration',
    color: 'cyan',
    tasks: []
  },
  {
    id: 'evening',
    label: 'Wind Down',
    startHour: 17,
    endHour: 20,
    vibeGoal: 'Active Relaxation',
    color: 'violet',
    tasks: []
  },
  {
    id: 'night',
    label: 'Quiet Night',
    startHour: 20,
    endHour: 23,
    vibeGoal: 'Reflection & Prep',
    color: 'slate',
    tasks: []
  }
];

export const ICONS = {
  Plus: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
  ),
  Trash: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
  ),
  Edit: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
  ),
  Moon: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
  ),
  Sun: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>
  ),
  Check: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
  ),
  Clock: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
  ),
  Target: () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>
  )
};
